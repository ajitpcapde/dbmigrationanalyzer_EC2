#!/bin/bash
# ============================================================
# AWS Database Migration Analyzer - Application Deployment Script
# ============================================================
# This script deploys the application files to an EC2 instance.
# Run after setup-ec2.sh has completed.
#
# Usage:
#   chmod +x scripts/deploy-app.sh
#   sudo ./scripts/deploy-app.sh
# ============================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
APP_DIR="/opt/dbmigration"
APP_USER="dbmigration"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$(dirname "$SCRIPT_DIR")"

echo -e "${BLUE}================================================${NC}"
echo -e "${BLUE}  AWS DB Migration Analyzer - Deploy Application${NC}"
echo -e "${BLUE}================================================${NC}"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Please run as root or with sudo${NC}"
    exit 1
fi

# Check if setup has been run
if [ ! -d "$APP_DIR/venv" ]; then
    echo -e "${RED}Error: Virtual environment not found${NC}"
    echo "Please run setup-ec2.sh first"
    exit 1
fi

echo -e "${YELLOW}Source Directory:${NC} $SOURCE_DIR"
echo -e "${YELLOW}Target Directory:${NC} $APP_DIR"
echo ""

# ============================================================
# Step 1: Stop the application if running
# ============================================================
echo -e "${YELLOW}Step 1: Stopping application...${NC}"

if systemctl is-active --quiet dbmigration; then
    systemctl stop dbmigration
    echo -e "${GREEN}✓ Application stopped${NC}"
else
    echo -e "${GREEN}✓ Application not running${NC}"
fi

# ============================================================
# Step 2: Backup existing files
# ============================================================
echo -e "\n${YELLOW}Step 2: Creating backup...${NC}"

BACKUP_DIR="$APP_DIR/backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

# Backup Python files
if ls $APP_DIR/*.py 1> /dev/null 2>&1; then
    cp $APP_DIR/*.py "$BACKUP_DIR/" 2>/dev/null || true
fi

echo -e "${GREEN}✓ Backup created at $BACKUP_DIR${NC}"

# ============================================================
# Step 3: Copy application files
# ============================================================
echo -e "\n${YELLOW}Step 3: Copying application files...${NC}"

# Copy Python files
cp "$SOURCE_DIR"/*.py "$APP_DIR/" 2>/dev/null || true

# Copy requirements
if [ -f "$SOURCE_DIR/requirements.txt" ]; then
    cp "$SOURCE_DIR/requirements.txt" "$APP_DIR/"
fi

# Copy config files
if [ -d "$SOURCE_DIR/config" ]; then
    cp -r "$SOURCE_DIR/config/"* "$APP_DIR/" 2>/dev/null || true
fi

# Copy Firebase config if exists
if [ -f "$SOURCE_DIR/firebase-config.json" ]; then
    cp "$SOURCE_DIR/firebase-config.json" "$APP_DIR/"
    chmod 600 "$APP_DIR/firebase-config.json"
fi

echo -e "${GREEN}✓ Application files copied${NC}"

# ============================================================
# Step 4: Set permissions
# ============================================================
echo -e "\n${YELLOW}Step 4: Setting permissions...${NC}"

chown -R $APP_USER:$APP_USER $APP_DIR
chmod 755 $APP_DIR
chmod 644 $APP_DIR/*.py 2>/dev/null || true

# Secure sensitive files
if [ -f "$APP_DIR/firebase-config.json" ]; then
    chmod 600 "$APP_DIR/firebase-config.json"
    chown $APP_USER:$APP_USER "$APP_DIR/firebase-config.json"
fi

echo -e "${GREEN}✓ Permissions set${NC}"

# ============================================================
# Step 5: Update Python dependencies
# ============================================================
echo -e "\n${YELLOW}Step 5: Updating Python dependencies...${NC}"

source $APP_DIR/venv/bin/activate
pip install --upgrade pip
pip install -r $APP_DIR/requirements.txt --quiet

echo -e "${GREEN}✓ Dependencies updated${NC}"

# ============================================================
# Step 6: Verify application files
# ============================================================
echo -e "\n${YELLOW}Step 6: Verifying application files...${NC}"

REQUIRED_FILES=(
    "streamlit_app.py"
    "ec2_config.py"
    "streamlit_app_ec2.py"
)

MISSING_FILES=0
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$APP_DIR/$file" ]; then
        echo -e "${RED}✗ Missing: $file${NC}"
        MISSING_FILES=$((MISSING_FILES + 1))
    else
        echo -e "${GREEN}✓ Found: $file${NC}"
    fi
done

if [ $MISSING_FILES -gt 0 ]; then
    echo -e "\n${RED}Warning: $MISSING_FILES required file(s) missing${NC}"
fi

# ============================================================
# Step 7: Test configuration
# ============================================================
echo -e "\n${YELLOW}Step 7: Testing configuration...${NC}"

source $APP_DIR/venv/bin/activate
cd $APP_DIR
python3 -c "
from ec2_config import load_ec2_config, secrets
config = load_ec2_config()
print('Configuration sections:', list(config.keys()))
print('Anthropic API:', 'ANTHROPIC_API_KEY' in config)
print('Firebase:', 'firebase' in config)
print('Admin:', 'admin' in config)
" 2>/dev/null && echo -e "${GREEN}✓ Configuration loaded successfully${NC}" || echo -e "${YELLOW}⚠ Configuration test skipped${NC}"

# ============================================================
# Step 8: Start the application
# ============================================================
echo -e "\n${YELLOW}Step 8: Starting application...${NC}"

systemctl start dbmigration
sleep 3

if systemctl is-active --quiet dbmigration; then
    echo -e "${GREEN}✓ Application started successfully${NC}"
else
    echo -e "${RED}✗ Application failed to start${NC}"
    echo "Check logs with: journalctl -u dbmigration -n 50"
    exit 1
fi

# Ensure nginx is running
systemctl start nginx 2>/dev/null || true
systemctl enable nginx 2>/dev/null || true
systemctl enable dbmigration 2>/dev/null || true

# ============================================================
# Final Summary
# ============================================================
echo -e "\n${BLUE}================================================${NC}"
echo -e "${BLUE}  Deployment Complete!${NC}"
echo -e "${BLUE}================================================${NC}"
echo ""

# Get public IP
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo "YOUR_EC2_IP")

echo -e "${GREEN}Application deployed successfully!${NC}"
echo ""
echo -e "${YELLOW}Access the application at:${NC}"
echo "  http://$PUBLIC_IP"
echo ""
echo -e "${YELLOW}Service Status:${NC}"
systemctl is-active dbmigration && echo -e "  ${GREEN}✓ DB Migration Analyzer: Running${NC}" || echo -e "  ${RED}✗ DB Migration Analyzer: Not Running${NC}"
systemctl is-active nginx && echo -e "  ${GREEN}✓ Nginx: Running${NC}" || echo -e "  ${RED}✗ Nginx: Not Running${NC}"
echo ""
echo -e "${YELLOW}View logs:${NC}"
echo "  sudo journalctl -u dbmigration -f"
echo ""
