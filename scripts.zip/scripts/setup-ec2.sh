#!/bin/bash
# ============================================================
# AWS Database Migration Analyzer - EC2 Setup Script
# ============================================================
# This script sets up an EC2 instance for running the application.
# Run as root or with sudo privileges.
#
# Usage: 
#   chmod +x scripts/setup-ec2.sh
#   sudo ./scripts/setup-ec2.sh
# ============================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="dbmigration"
APP_DIR="/opt/dbmigration"
APP_USER="dbmigration"
STREAMLIT_PORT=8501

echo -e "${BLUE}================================================${NC}"
echo -e "${BLUE}  AWS Database Migration Analyzer - EC2 Setup${NC}"
echo -e "${BLUE}================================================${NC}"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Please run as root or with sudo${NC}"
    exit 1
fi

# Detect OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    VERSION=$VERSION_ID
else
    echo -e "${RED}Cannot detect OS${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Detected OS: $OS $VERSION${NC}"

# ============================================================
# Step 1: System Update and Dependencies
# ============================================================
echo -e "\n${YELLOW}Step 1: Installing system dependencies...${NC}"

if [ "$OS" == "ubuntu" ] || [ "$OS" == "debian" ]; then
    apt-get update -y
    apt-get install -y \
        python3 \
        python3-pip \
        python3-venv \
        python3-dev \
        nginx \
        git \
        curl \
        wget \
        unzip \
        htop \
        jq \
        build-essential \
        libffi-dev \
        libssl-dev
        
elif [ "$OS" == "amzn" ] || [ "$OS" == "rhel" ] || [ "$OS" == "centos" ]; then
    yum update -y
    yum install -y \
        python3 \
        python3-pip \
        python3-devel \
        nginx \
        git \
        curl \
        wget \
        unzip \
        htop \
        jq \
        gcc \
        libffi-devel \
        openssl-devel
fi

echo -e "${GREEN}✓ System dependencies installed${NC}"

# ============================================================
# Step 2: Create Application User
# ============================================================
echo -e "\n${YELLOW}Step 2: Creating application user...${NC}"

if ! id "$APP_USER" &>/dev/null; then
    useradd -r -s /bin/bash -d $APP_DIR $APP_USER
    echo -e "${GREEN}✓ User '$APP_USER' created${NC}"
else
    echo -e "${GREEN}✓ User '$APP_USER' already exists${NC}"
fi

# ============================================================
# Step 3: Create Application Directory Structure
# ============================================================
echo -e "\n${YELLOW}Step 3: Creating application directory structure...${NC}"

mkdir -p $APP_DIR
mkdir -p $APP_DIR/logs
mkdir -p $APP_DIR/data
mkdir -p /var/log/$APP_NAME
mkdir -p /etc/$APP_NAME

chown -R $APP_USER:$APP_USER $APP_DIR
chown -R $APP_USER:$APP_USER /var/log/$APP_NAME

echo -e "${GREEN}✓ Directory structure created${NC}"

# ============================================================
# Step 4: Create Python Virtual Environment
# ============================================================
echo -e "\n${YELLOW}Step 4: Creating Python virtual environment...${NC}"

python3 -m venv $APP_DIR/venv
source $APP_DIR/venv/bin/activate

# Upgrade pip
pip install --upgrade pip wheel setuptools

echo -e "${GREEN}✓ Virtual environment created${NC}"

# ============================================================
# Step 5: Install Python Dependencies
# ============================================================
echo -e "\n${YELLOW}Step 5: Installing Python dependencies...${NC}"

# Create requirements.txt if not present
if [ ! -f "$APP_DIR/requirements.txt" ]; then
    cat > $APP_DIR/requirements.txt << 'EOF'
# Core Streamlit Framework
streamlit>=1.28.0

# Data Manipulation and Analysis
pandas>=2.0.0
numpy>=1.24.0

# Visualization Libraries
plotly>=5.15.0
matplotlib>=3.7.0
seaborn>=0.12.0

# AWS Integration
boto3>=1.34.0
botocore>=1.34.0

# Anthropic AI
anthropic>=0.40.0

# Configuration and Data Processing
PyYAML>=6.0
requests>=2.31.0

# Firebase Authentication
firebase-admin>=6.2.0
google-cloud-firestore>=2.11.1
google-auth>=2.17.0

# PDF Report Generation
reportlab>=3.6.0

# Excel File Processing
openpyxl>=3.1.0
xlsxwriter>=3.1.0

# Enhanced UI Components
streamlit-aggrid>=0.3.4
streamlit-option-menu>=0.3.6

# Mathematical Models
scipy>=1.11.0

# Environment loading
python-dotenv>=1.0.0
EOF
fi

pip install -r $APP_DIR/requirements.txt

echo -e "${GREEN}✓ Python dependencies installed${NC}"

# ============================================================
# Step 6: Configure Nginx Reverse Proxy
# ============================================================
echo -e "\n${YELLOW}Step 6: Configuring Nginx reverse proxy...${NC}"

cat > /etc/nginx/sites-available/$APP_NAME << 'EOF'
upstream streamlit {
    server 127.0.0.1:8501;
    keepalive 32;
}

server {
    listen 80;
    server_name _;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Logging
    access_log /var/log/nginx/dbmigration-access.log;
    error_log /var/log/nginx/dbmigration-error.log;
    
    # Client settings
    client_max_body_size 200M;
    
    # Streamlit WebSocket support
    location / {
        proxy_pass http://streamlit;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 86400;
        proxy_buffering off;
    }
    
    # Streamlit specific paths
    location /_stcore/stream {
        proxy_pass http://streamlit/_stcore/stream;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_read_timeout 86400;
        proxy_buffering off;
    }
    
    # Health check endpoint
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF

# Enable site
if [ "$OS" == "ubuntu" ] || [ "$OS" == "debian" ]; then
    mkdir -p /etc/nginx/sites-enabled
    ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
    rm -f /etc/nginx/sites-enabled/default
else
    # For Amazon Linux / RHEL
    mkdir -p /etc/nginx/conf.d
    cp /etc/nginx/sites-available/$APP_NAME /etc/nginx/conf.d/$APP_NAME.conf
fi

# Test nginx configuration
nginx -t

echo -e "${GREEN}✓ Nginx configured${NC}"

# ============================================================
# Step 7: Create Systemd Service
# ============================================================
echo -e "\n${YELLOW}Step 7: Creating systemd service...${NC}"

cat > /etc/systemd/system/$APP_NAME.service << EOF
[Unit]
Description=AWS Database Migration Analyzer AI
After=network.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin"
EnvironmentFile=/etc/$APP_NAME/.env
ExecStart=$APP_DIR/venv/bin/streamlit run streamlit_app_ec2.py \\
    --server.port=8501 \\
    --server.address=127.0.0.1 \\
    --server.headless=true \\
    --server.runOnSave=false \\
    --browser.gatherUsageStats=false \\
    --server.enableCORS=false \\
    --server.enableXsrfProtection=true \\
    --server.maxUploadSize=200
ExecReload=/bin/kill -HUP \$MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=$APP_NAME

# Security hardening
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=$APP_DIR/logs $APP_DIR/data /var/log/$APP_NAME

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd
systemctl daemon-reload

echo -e "${GREEN}✓ Systemd service created${NC}"

# ============================================================
# Step 8: Create Environment File Template
# ============================================================
echo -e "\n${YELLOW}Step 8: Creating environment configuration...${NC}"

if [ ! -f "/etc/$APP_NAME/.env" ]; then
    cat > /etc/$APP_NAME/.env << 'EOF'
# AWS Database Migration Analyzer - EC2 Configuration
# Edit this file with your settings

# Anthropic AI (Required for AI features)
ANTHROPIC_API_KEY=sk-ant-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# AWS Configuration (leave empty to use IAM Role - RECOMMENDED)
AWS_DEFAULT_REGION=us-east-1

# Admin Credentials
ADMIN_EMAIL=admin@yourcompany.com
ADMIN_PASSWORD=change-this-password-immediately
ADMIN_KEY=your-admin-secret-key

# Firebase (Optional - for user authentication)
# Add Firebase credentials here or use firebase-config.json file
# FIREBASE_PROJECT_ID=your-project-id
# FIREBASE_WEB_API_KEY=your-web-api-key

# Application Mode
APP_MODE=production
EOF

    chmod 600 /etc/$APP_NAME/.env
    chown $APP_USER:$APP_USER /etc/$APP_NAME/.env
    echo -e "${GREEN}✓ Environment file created at /etc/$APP_NAME/.env${NC}"
else
    echo -e "${YELLOW}⚠ Environment file already exists, skipping${NC}"
fi

# ============================================================
# Step 9: Create Logrotate Configuration
# ============================================================
echo -e "\n${YELLOW}Step 9: Configuring log rotation...${NC}"

cat > /etc/logrotate.d/$APP_NAME << EOF
/var/log/$APP_NAME/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 $APP_USER $APP_USER
    sharedscripts
    postrotate
        systemctl reload $APP_NAME >/dev/null 2>&1 || true
    endscript
}
EOF

echo -e "${GREEN}✓ Log rotation configured${NC}"

# ============================================================
# Step 10: Create Maintenance Scripts
# ============================================================
echo -e "\n${YELLOW}Step 10: Creating maintenance scripts...${NC}"

mkdir -p $APP_DIR/scripts

# Start script
cat > $APP_DIR/scripts/start.sh << 'EOF'
#!/bin/bash
sudo systemctl start dbmigration
sudo systemctl start nginx
echo "✓ Application started"
echo "  Access at: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4 2>/dev/null || echo 'YOUR_EC2_IP')"
EOF

# Stop script
cat > $APP_DIR/scripts/stop.sh << 'EOF'
#!/bin/bash
sudo systemctl stop dbmigration
echo "✓ Application stopped"
EOF

# Restart script
cat > $APP_DIR/scripts/restart.sh << 'EOF'
#!/bin/bash
sudo systemctl restart dbmigration
echo "✓ Application restarted"
EOF

# Status script
cat > $APP_DIR/scripts/status.sh << 'EOF'
#!/bin/bash
echo "=== Service Status ==="
systemctl status dbmigration --no-pager
echo ""
echo "=== Nginx Status ==="
systemctl status nginx --no-pager
echo ""
echo "=== Recent Logs ==="
journalctl -u dbmigration -n 20 --no-pager
EOF

# Update script
cat > $APP_DIR/scripts/update.sh << 'EOF'
#!/bin/bash
cd /opt/dbmigration
source venv/bin/activate
pip install --upgrade -r requirements.txt
sudo systemctl restart dbmigration
echo "✓ Application updated and restarted"
EOF

chmod +x $APP_DIR/scripts/*.sh
chown -R $APP_USER:$APP_USER $APP_DIR/scripts

echo -e "${GREEN}✓ Maintenance scripts created${NC}"

# ============================================================
# Final Summary
# ============================================================
echo -e "\n${BLUE}================================================${NC}"
echo -e "${BLUE}  Setup Complete!${NC}"
echo -e "${BLUE}================================================${NC}"
echo ""
echo -e "${GREEN}Installation Directory:${NC} $APP_DIR"
echo -e "${GREEN}Configuration File:${NC} /etc/$APP_NAME/.env"
echo -e "${GREEN}Log Directory:${NC} /var/log/$APP_NAME"
echo ""
echo -e "${YELLOW}Next Steps:${NC}"
echo "1. Copy your application files to $APP_DIR/"
echo "2. Edit configuration: sudo nano /etc/$APP_NAME/.env"
echo "   - Add your ANTHROPIC_API_KEY"
echo "   - Configure ADMIN credentials"
echo "   - (Optional) Add Firebase configuration"
echo "3. Start the application: sudo systemctl start $APP_NAME"
echo "4. Start Nginx: sudo systemctl start nginx"
echo "5. Enable auto-start: sudo systemctl enable $APP_NAME nginx"
echo ""
echo -e "${YELLOW}Useful Commands:${NC}"
echo "  Start:   sudo systemctl start $APP_NAME"
echo "  Stop:    sudo systemctl stop $APP_NAME"
echo "  Restart: sudo systemctl restart $APP_NAME"
echo "  Status:  sudo systemctl status $APP_NAME"
echo "  Logs:    sudo journalctl -u $APP_NAME -f"
echo ""
echo -e "${GREEN}Access the application at:${NC}"
echo "  http://YOUR_EC2_PUBLIC_IP"
echo ""
